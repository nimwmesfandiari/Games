// ========== PREMIUM PAGE JAVASCRIPT ==========

// Data Model - فقط اشتراک ماهانه ۲۰,۰۰۰ تومانی
const PremiumData = {
    features: [
        {
            id: 1,
            title: 'چت نامحدود',
            description: 'بدون محدودیت با تمام کاربران چت کنید و از گفت‌وگوهای نامحدود لذت ببرید',
            icon: 'fa-comments',
            color: '#a855f7'
        },
        {
            id: 2,
            title: 'ارسال فایل',
            description: 'ارسال انواع فایل تا حجم 2GB شامل عکس، ویدیو، سند و فایل‌های دیگر',
            icon: 'fa-file-upload',
            color: '#9333ea'
        },
        {
            id: 3,
            title: 'تماس ویدیویی',
            description: 'تماس ویدیویی با کیفیت بالا 1080p و بدون محدودیت زمانی',
            icon: 'fa-video',
            color: '#7e22ce'
        },
        {
            id: 4,
            title: 'بدون تبلیغات',
            description: 'تجربه کاربری بدون هیچگونه تبلیغات مزاحم و تمرکز کامل روی محتوا',
            icon: 'fa-ad',
            color: '#6b21a8'
        },
        {
            id: 5,
            title: 'امنیت پیشرفته',
            description: 'رمزنگاری end-to-end برای حریم خصوصی و امنیت اطلاعات شما',
            icon: 'fa-shield-alt',
            color: '#a855f7'
        },
        {
            id: 6,
            title: 'پشتیبانی ویژه',
            description: 'پشتیبانی 24 ساعته VIP با اولویت پاسخگویی فوری',
            icon: 'fa-headset',
            color: '#9333ea'
        },
        {
            id: 7,
            title: 'آپلود نامحدود',
            description: 'آپلود بدون محدودیت ویدیو، عکس و فایل در تمام بخش‌های برنامه',
            icon: 'fa-cloud-upload',
            color: '#7e22ce'
        },
        {
            id: 8,
            title: 'تم شخصی',
            description: 'سفارشی‌سازی کامل ظاهر برنامه با تم‌های رنگ مختلف',
            icon: 'fa-palette',
            color: '#6b21a8'
        }
    ],
    
    // فقط یک پلن ماهانه ۲۰,۰۰۰ تومانی
    plans: [
        {
            id: 1,
            title: 'ماهانه',
            price: '۲۰,۰۰۰',
            period: 'ماه',
            features: [
                'چت نامحدود',
                'ارسال فایل تا 2GB',
                'تماس ویدیویی 1080p',
                'بدون تبلیغات',
                'امنیت پیشرفته',
                'پشتیبانی VIP',
                'آپلود نامحدود',
                'تم شخصی'
            ],
            isPopular: true
        }
    ],
    
    testimonials: [
        {
            id: 1,
            name: 'سارا محمدی',
            role: 'طراح UI/UX',
            avatar: 'س',
            rating: 5,
            comment: 'بهترین سرمایه‌گذاری بود! تمام امکاناتی که نیاز داشتم در یک جا جمع شده.',
            color: '#a855f7'
        },
        {
            id: 2,
            name: 'علی رضایی',
            role: 'توسعه‌دهنده',
            avatar: 'ع',
            rating: 5,
            comment: 'پشتیبانی عالی و امکانات بی‌نظیر. واقعاً ارزشش رو داره.',
            color: '#9333ea'
        },
        {
            id: 3,
            name: 'نازنین کریمی',
            role: 'مدیر پروژه',
            avatar: 'ن',
            rating: 4,
            comment: 'کیفیت خدمات فوق‌العاده است. مخصوصاً بخش چت و ویدیو.',
            color: '#7e22ce'
        }
    ]
};

// State Management
const PremiumState = {
    selectedPlan: null,
    hasPremium: localStorage.getItem('hasPremium') === 'true' || false,
    totalSubscribers: 1250
};

// DOM Elements
const PremiumElements = {
    premiumFeatures: document.getElementById('premiumFeatures'),
    paymentPlans: document.getElementById('paymentPlans'),
    statsContainer: document.getElementById('statsContainer'),
    testimonialsContainer: null
};

// Initialize Premium Page
function initializePremiumPage() {
    console.log('👑 Initializing Premium Page...');
    
    // Render stats
    renderStats();
    
    // Render premium features
    renderPremiumFeatures();
    
    // Render single payment plan
    renderPaymentPlan();
    
    // Create testimonials section
    createTestimonialsSection();
    
    // Check premium status
    checkPremiumUserStatus();
    
    console.log('✅ Premium Page Initialized');
}

// Render Stats
function renderStats() {
    if (!PremiumElements.statsContainer) return;
    
    PremiumElements.statsContainer.innerHTML = `
        <div class="stat-card">
            <div class="stat-icon" style="color: #a855f7; background: rgba(168, 85, 247, 0.1);">
                <i class="fas fa-crown"></i>
            </div>
            <div class="stat-value">${PremiumState.totalSubscribers.toLocaleString('fa-IR')}</div>
            <div class="stat-label">کاربر پریمیوم</div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon" style="color: #a855f7; background: rgba(168, 85, 247, 0.1);">
                <i class="fas fa-star"></i>
            </div>
            <div class="stat-value">۴.۸</div>
            <div class="stat-label">میانگین امتیاز</div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon" style="color: #a855f7; background: rgba(168, 85, 247, 0.1);">
                <i class="fas fa-check-circle"></i>
            </div>
            <div class="stat-value">۹۸٪</div>
            <div class="stat-label">رضایت کاربران</div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon" style="color: #a855f7; background: rgba(168, 85, 247, 0.1);">
                <i class="fas fa-shield-alt"></i>
            </div>
            <div class="stat-value">۱۰۰٪</div>
            <div class="stat-label">امنیت تضمینی</div>
        </div>
    `;
}

// Render Premium Features
function renderPremiumFeatures() {
    if (!PremiumElements.premiumFeatures) return;
    
    PremiumElements.premiumFeatures.innerHTML = '';
    
    PremiumData.features.forEach(feature => {
        const featureCard = createFeatureCard(feature);
        PremiumElements.premiumFeatures.appendChild(featureCard);
    });
}

// Create Feature Card
function createFeatureCard(feature) {
    const card = document.createElement('div');
    card.className = 'premium-feature-card';
    
    card.innerHTML = `
        <div class="premium-feature-icon" style="background: rgba(168, 85, 247, 0.15); color: ${feature.color};">
            <i class="fas ${feature.icon}"></i>
        </div>
        <h3 class="premium-feature-title">${feature.title}</h3>
        <p class="premium-feature-description">${feature.description}</p>
    `;
    
    return card;
}

// Render Single Payment Plan
function renderPaymentPlan() {
    if (!PremiumElements.paymentPlans) return;
    
    PremiumElements.paymentPlans.innerHTML = '';
    
    const plan = PremiumData.plans[0]; // فقط یک پلن داریم
    const planCard = createPlanCard(plan);
    PremiumElements.paymentPlans.appendChild(planCard);
}

// Create Plan Card
function createPlanCard(plan) {
    const card = document.createElement('div');
    card.className = `payment-plan ${plan.isPopular ? 'popular' : ''}`;
    card.dataset.planId = plan.id;
    
    const buttonText = PremiumState.hasPremium ? 'تمدید اشتراک' : 'خرید اشتراک';
    const buttonIcon = PremiumState.hasPremium ? 'fa-redo' : 'fa-shopping-cart';
    
    card.innerHTML = `
        ${plan.isPopular ? '<div class="popular-badge">پیشنهاد ویژه</div>' : ''}
        <div class="plan-icon">
            <i class="fas fa-crown"></i>
        </div>
        <h3 class="plan-title">${plan.title}</h3>
        <div class="plan-price">${plan.price}</div>
        <div class="plan-period">تومان / ${plan.period}</div>
        
        <div class="plan-features">
            ${plan.features.map(feature => `
                <div class="plan-feature">
                    <i class="fas fa-check-circle"></i>
                    <span>${feature}</span>
                </div>
            `).join('')}
        </div>
        
        <button class="payment-button" onclick="redirectToPayment()">
            <i class="fas ${buttonIcon}"></i>
            ${buttonText}
        </button>
        
        <div style="margin-top: 20px; text-align: center;">
            <span style="background: rgba(34, 197, 94, 0.2); color: #22c55e; padding: 5px 15px; border-radius: 20px; font-size: 14px;">
                تضمین بازگشت وجه ۷ روزه
            </span>
        </div>
    `;
    
    return card;
}

// Create Testimonials Section
function createTestimonialsSection() {
    const testimonialsHTML = `
        <div style="margin-top: 60px;">
            <h2 class="section-title">
                <i class="fas fa-comment"></i>
                نظرات کاربران پریمیوم
            </h2>
            <p style="color: #94a3b8; text-align: center; margin-bottom: 30px;">
                تجربه کاربران از خدمات ما
            </p>
            
            <div class="premium-testimonials">
                ${PremiumData.testimonials.map(testimonial => `
                    <div class="testimonial-card">
                        <div class="testimonial-header">
                            <div class="testimonial-avatar" style="background: linear-gradient(135deg, ${testimonial.color}, ${darkenColor(testimonial.color, 20)});">
                                ${testimonial.avatar}
                            </div>
                            <div style="flex: 1;">
                                <h4 style="color: white; margin-bottom: 5px;">${testimonial.name}</h4>
                                <p style="color: #94a3b8; font-size: 13px;">${testimonial.role}</p>
                            </div>
                        </div>
                        
                        <div class="testimonial-rating">
                            ${'<i class="fas fa-star"></i>'.repeat(testimonial.rating)}
                        </div>
                        
                        <p class="testimonial-text">"${testimonial.comment}"</p>
                    </div>
                `).join('')}
            </div>
        </div>
    `;
    
    // Insert after payment plans
    if (PremiumElements.paymentPlans) {
        PremiumElements.paymentPlans.insertAdjacentHTML('afterend', testimonialsHTML);
    }
}

// Redirect to Payment Page
function redirectToPayment() {
    // نمایش پیام در حال انتقال
    showRedirectMessage();
    
    // انتقال به صفحه پرداخت بعد از 2 ثانیه
    setTimeout(() => {
        // اگر کاربر قبلاً پریمیوم دارد، تمدید می‌کند
        if (PremiumState.hasPremium) {
            processRenewal();
        } else {
            // انتقال به صفحه پرداخت اصلی
            window.location.href = 'Pay/index.php';
        }
    }, 2000);
}

// Show Redirect Message
function showRedirectMessage() {
    const redirectHTML = `
        <div class="popup-overlay" style="display: flex; z-index: 10000;">
            <div class="popup-content" style="max-width: 400px; text-align: center;">
                <div class="loading" style="width: 50px; height: 50px; margin: 0 auto 25px; border: 4px solid rgba(168, 85, 247, 0.2); border-top: 4px solid #a855f7; border-radius: 50%; animation: spin 1s linear infinite;"></div>
                
                <style>
                    @keyframes spin {
                        0% { transform: rotate(0deg); }
                        100% { transform: rotate(360deg); }
                    }
                </style>
                
                <h2 style="color: white; margin-bottom: 15px; font-size: 22px;">
                    <i class="fas fa-credit-card" style="color: #a855f7; margin-left: 10px;"></i>
                    انتقال به درگاه پرداخت
                </h2>
                
                <p style="color: #cbd5e1; margin-bottom: 25px; line-height: 1.6;">
                    در حال انتقال به صفحه پرداخت امن...
                    <br>
                    <span style="color: #94a3b8; font-size: 14px;">لطفاً منتظر بمانید</span>
                </p>
                
                <div style="background: rgba(168, 85, 247, 0.1); border-radius: 12px; padding: 20px; margin-bottom: 20px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 10px;">
                        <span style="color: #94a3b8;">مبلغ:</span>
                        <span style="color: #fbbf24; font-weight: 500; font-size: 18px;">۲۰,۰۰۰ تومان</span>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                        <span style="color: #94a3b8;">دوره:</span>
                        <span style="color: white; font-weight: 500;">ماهانه</span>
                    </div>
                </div>
                
                <div style="color: #94a3b8; font-size: 13px; background: rgba(255, 255, 255, 0.05); padding: 15px; border-radius: 12px; margin-top: 15px;">
                    <i class="fas fa-shield-alt" style="color: #10b981; margin-left: 8px;"></i>
                    پرداخت شما کاملاً امن است
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', redirectHTML);
}

// Process Renewal
function processRenewal() {
    // نمایش پیام تمدید
    const renewalHTML = `
        <div class="popup-overlay" style="display: flex;">
            <div class="popup-content" style="max-width: 500px; text-align: center;">
                <button class="popup-close" onclick="this.parentElement.parentElement.style.display='none'">
                    <i class="fas fa-times"></i>
                </button>
                
                <div class="popup-icon" style="color: #10b981; animation: none;">
                    <i class="fas fa-crown"></i>
                </div>
                
                <h2 class="popup-title" style="background: linear-gradient(to right, #10b981, #059669);">
                    تمدید اشتراک
                </h2>
                
                <p class="popup-text">
                    در حال انتقال به صفحه تمدید اشتراک...
                </p>
                
                <div style="background: rgba(255, 255, 255, 0.05); border-radius: 16px; padding: 25px; margin-bottom: 25px;">
                    <div style="text-align: center; margin-bottom: 20px;">
                        <div style="font-size: 32px; color: #fbbf24; font-weight: 700; margin-bottom: 5px;">۲۰,۰۰۰</div>
                        <div style="color: #94a3b8;">تومان / ماهانه</div>
                    </div>
                    
                    <div style="border-top: 1px solid rgba(255, 255, 255, 0.1); padding-top: 20px;">
                        <div style="display: flex; flex-direction: column; gap: 15px;">
                            <div style="display: flex; align-items: center; justify-content: space-between;">
                                <span style="color: #94a3b8;">اشتراک فعلی:</span>
                                <span style="color: white; font-weight: 500;">فعال</span>
                            </div>
                            <div style="display: flex; align-items: center; justify-content: space-between;">
                                <span style="color: #94a3b8;">پس از تمدید:</span>
                                <span style="color: #10b981; font-weight: 500;">${getRenewalDate('ماه')}</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="loading" style="width: 40px; height: 40px; margin: 20px auto; border: 3px solid rgba(168, 85, 247, 0.2); border-top: 3px solid #a855f7; border-radius: 50%; animation: spin 1s linear infinite;"></div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', renewalHTML);
    
    // انتقال به صفحه پرداخت برای تمدید
    setTimeout(() => {
        window.location.href = 'Pay/index.php?renewal=true';
    }, 3000);
}

// Get Renewal Date
function getRenewalDate(period) {
    const now = new Date();
    let renewalDate = new Date(now.setMonth(now.getMonth() + 1));
    return renewalDate.toLocaleDateString('fa-IR');
}

// Check Premium User Status
function checkPremiumUserStatus() {
    if (PremiumState.hasPremium) {
        // Update UI for premium users
        updatePremiumUserUI();
    }
}

// Update Premium User UI
function updatePremiumUserUI() {
    // Update payment button text
    const paymentButton = document.querySelector('.payment-button');
    if (paymentButton) {
        paymentButton.innerHTML = '<i class="fas fa-redo"></i> تمدید اشتراک';
    }
    
    // Add premium badge to header
    const header = document.querySelector('.app-header');
    if (header) {
        const premiumBadge = document.createElement('div');
        premiumBadge.style.cssText = `
            position: absolute;
            top: 20px;
            left: 20px;
            background: linear-gradient(135deg, #fbbf24, #f59e0b);
            color: #1a1a2e;
            padding: 8px 20px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: 700;
            display: flex;
            align-items: center;
            gap: 8px;
            z-index: 10;
        `;
        premiumBadge.innerHTML = `
            <i class="fas fa-crown"></i>
            کاربر پریمیوم
        `;
        header.style.position = 'relative';
        header.appendChild(premiumBadge);
    }
}

// Helper Function
function darkenColor(color, percent = 20) {
    // This is a simplified version
    return color;
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', initializePremiumPage);

// Make functions available globally
window.redirectToPayment = redirectToPayment;
window.processRenewal = processRenewal;